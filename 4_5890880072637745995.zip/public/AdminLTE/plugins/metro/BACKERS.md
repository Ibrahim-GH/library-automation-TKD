<h1 align="center">Sponsors &amp; Backers</h1>

Metro 4 is an MIT-licensed open source project. 
It's an independent project with its ongoing development made possible entirely thanks to the support by these awesome Backers. 
If you'd like to join them, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/metroui)
- [Become a backer or sponsor on Open Collective](https://opencollective.com/metro4#backer)

<!--
<h2 align="center">Platinum via Patreon</h2>
-->

<!--
<h2 align="center">Gold via Patreon</h2>
-->

<!--
<h2 align="center">Silver via Patreon</h2>
-->

<!--
<h2 align="center">Bronze via Patreon</h2>
-->

<!--
<h2 align="center">Generous Backers via Patreon ($50+)</h2>
-->

<h2 align="center">Backers via Patreon</h2>

 - [Riku](https://www.patreon.com/user/creators?u=8976699) <small>(The first backer for Metro 4!)</small>
 - [Jonathan](https://www.patreon.com/user/creators?u=10019621) 
 - [Mike](https://www.patreon.com/user/creators?u=2603858) 
 - [Hebert Alves](https://www.patreon.com/user/creators?u=10134199)
 - [Arnaud Dagnelies](https://www.patreon.com/user/creators?u=13947239)

<h2 align="center">Project donors (one pay or former patron)</h2>

 - [Chaoswriter96](https://github.com/Chaoswriter96)
 - [chongzia](https://www.patreon.com/user/creators?u=10094916)
 - [TorakikiSan](https://github.com/TorakikiSan)
