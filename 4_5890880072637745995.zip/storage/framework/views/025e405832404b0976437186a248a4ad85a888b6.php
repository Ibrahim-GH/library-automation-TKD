<?php $__env->startSection('title', 'Edit Bill'); ?>

<?php $__env->startSection('head'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-truck"></i> <?php echo e(__('Bill')); ?>

                <small><?php echo e(__('Edit')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.bills.index')); ?>"><?php echo e(__('Bills')); ?></a></li>
                <li class="active"><?php echo e(__('Edit')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Horizontal Form -->
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Edit Bill')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <?php echo e(Form::model($bill, ['route' => ['dashboard.bills.update', $bill->id], 'method' => 'put', 'id' => 'bill', 'autocomplete' => 'off'])); ?>

                        <?php echo e(Form::hidden('id')); ?>

                        <div class="box-body">
                            <div class="form-group <?php echo e($errors->has('supplier_id')? 'has-error' : ''); ?>">
                                <?php if($errors->has('supplier_id')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('supplier_id', __('Supplier') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::select('supplier_id', $suppliers, null, ['required', 'class' => 'form-control select2 supplier', 'placeholder' => __('Select Supplier') . '...' ])); ?>

                                <span class="help-block"><?php echo e($errors->first('supplier_id')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('date')? 'has-error' : ''); ?>">
                                <?php if($errors->has('date')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('date', __('Date') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::date('date', old('date'), ['required', 'class' => 'form-control', 'placeholder' => __('Select Date') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('time')? 'has-error' : ''); ?>">
                                <?php if($errors->has('time')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('time', __('Time') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::time('time', old('time'), ['required', 'class' => 'form-control', 'placeholder' => __('Select Time') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('time')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('order_id')? 'has-error' : ''); ?>">
                                <?php if($errors->has('order_id')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('order_id', __('Order ID') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::text('order_id', old('order_id'), ['class' => 'form-control', 'placeholder' => __('Enter Order ID') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('order_id')); ?></span>
                            </div>
                            <table class="table table-hover" id="bill_items">
                                <tr>
                                    <th><?php echo e(__('Item')); ?></th>
                                    <th><?php echo e(__('Unit')); ?></th>
                                    <th><?php echo e(__('Capacity')); ?></th>
                                    <th><?php echo e(__('Count')); ?></th>
                                    <th><?php echo e(__('Cost')); ?></th>
                                    <th><?php echo e(__('Total Cost')); ?></th>
                                    <th><?php echo e(__('Controls')); ?></th>
                                </tr>

                                <?php if(old('billItems')): ?>
                                    <?php $__currentLoopData = old('billItems'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $billItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="bill-item" data-index="<?php echo e($index); ?>">
                                            <td class="item-id <?php echo e($errors->has('billItems.' . $index . '.item_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('billItems[' . $index . '][item_id]', array_pluck($items, 'name', 'id'), $billItem['item_id'], ['required', 'placeholder' => __('Select Item') . '...', 'class' => 'form-control select2 items'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.item_id')); ?></span>
                                            </td>
                                            <td class="unit-id <?php echo e($errors->has('billItems.' . $index . '.unit_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('billItems[' . $index . '][unit_id]', array_pluck($items->find($billItem['item_id'])->units, 'name', 'id'), $billItem['unit_id'], ['required', 'placeholder' => __('Select Unit') . '...', 'class' => 'form-control select2 units'], $unitsOptions)); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.unit_id')); ?></span>
                                            </td>
                                            <td class="capacity <?php echo e($errors->has('billItems.' . $index . '.capacity')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('billItems[' . $index . '][capacity]', $billItem['capacity'], ['required', is_numeric($billItem['unit_id']) ? 'readonly' : '', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.capacity')); ?></span>

                                            </td>
                                            <td class="count <?php echo e($errors->has('billItems.' . $index . '.count')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('billItems[' . $index . '][count]', $billItem['count'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Count') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.count')); ?></span>

                                            </td>
                                            <td class="cost <?php echo e($errors->has('billItems.' . $index . '.cost')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('billItems[' . $index . '][cost]', $billItem['cost'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Cost') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.cost')); ?></span>
                                            </td>
                                            <td class="total-cost">
                                                <?php echo e($billItem['capacity'] * $billItem['count'] * $billItem['cost']); ?>

                                            </td>
                                            <td class="controls">
                                                <a class="btn btn-box-tool toggle-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-toggle-on"></i>
                                                </a>
                                                <a class="btn btn-box-tool delete-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $bill->billItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $billItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="bill-item" data-index="<?php echo e($index); ?>">
                                            <td class="item-id <?php echo e($errors->has('billItems.' . $index . '.item_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('billItems[' . $index . '][item_id]', array_pluck($items, 'name', 'id'), $billItem->item_id, ['required', 'placeholder' => __('Select Item') . '...', 'class' => 'form-control select2 items'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.item_id')); ?></span>
                                            </td>
                                            <td class="unit-id <?php echo e($errors->has('billItems.' . $index . '.unit_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('billItems[' . $index . '][unit_id]', array_pluck($items->find($billItem['item_id'])->units, 'name', 'id'), $billItem->unit_id, ['required', 'placeholder' => __('Select Unit') . '...', 'class' => 'form-control select2 units'], $unitsOptions)); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.unit_id')); ?></span>
                                            </td>
                                            <td class="capacity <?php echo e($errors->has('billItems.' . $index . '.capacity')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('billItems[' . $index . '][capacity]', $billItem->unit->capacity, ['required', 'readonly', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.capacity')); ?></span>

                                            </td>
                                            <td class="count <?php echo e($errors->has('billItems.' . $index . '.count')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('billItems[' . $index . '][count]', $billItem->count, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Count') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.count')); ?></span>

                                            </td>
                                            <td class="cost <?php echo e($errors->has('billItems.' . $index . '.cost')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('billItems[' . $index . '][cost]', $billItem->cost, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Cost') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('billItems.' . $index . '.cost')); ?></span>
                                            </td>
                                            <td class="total-cost">
                                                <?php echo e($billItem->unit->capacity * $billItem->count * $billItem->cost); ?>

                                            </td>
                                            <td class="controls">
                                                <a class="btn btn-box-tool toggle-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-toggle-on"></i>
                                                </a>
                                                <a class="btn btn-box-tool delete-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php endif; ?>
                            </table>
                            <div class="text-center <?php echo e($errors->has('billItems')? 'has-error' : ''); ?>">
                                <h4 class="help-block"><?php echo e($errors->first('billItems')); ?></h4>
                            </div>
                            <div class="form-group <?php echo e($errors->has('notes')? 'has-error' : ''); ?>">
                                <?php if($errors->has('notes')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('notes', 'Notes:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('notes', old('notes'), ['class' => 'form-control', 'placeholder' => 'Enter notes...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('notes')); ?></span>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <?php echo e(link_to_route('dashboard.bills.index', __('Back'), null, [ 'class' => 'btn btn-default', 'tabindex' => '-1' ])); ?>

                            <?php echo e(Form::submit('Update', ['class' => 'btn btn-primary pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                        <?php echo e(Form::close()); ?>

                    </div>
                    <!-- /.box -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('AdminLTE/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        let items = <?php echo json_encode($items, 15, 512) ?>;

        function totalCost() {
            var capacity = $(this).parents('.bill-item').find('.capacity input').val();
            var count = $(this).parents('.bill-item').find('.count input').val();
            var cost = $(this).parents('.bill-item').find('.cost input').val();
            $(this).parents('.bill-item').find('.total-cost').html(capacity * count * cost);
        }

        function changeItem(e) {
            $(this).parents('tr').find('.capacity input, .count input, .cost input').val('');

            var item = items.find(x => x.id == e.params.data.id);

            if (item) {
                var units = $(this).parents('tr').find('.select2.units').html($('<option selected value/>').text('<?php echo e(__('Select Unit')); ?>...'));

                item.units.forEach(function (unit) {
                    units.append($('<option value="' + unit.id + '" data-capacity="' + unit.capacity + '" data-item-id="' + item.id + '"/>').text(unit.name));
                });
            }
            else {
                var units = $(this).parents('tr').find('.select2.units').html($('<option selected value/>').text('<?php echo e(__('Select Unit')); ?>...'));
            }
        }

        function changeUnit(e) {

            var item = items.find(x => x.id == $(e.params.data.element).data('item-id'));

            if (item) {

                var unit = item.units.find(x => x.id == e.params.data.id);

                if (unit) {
                    $(this).parents('tr').find('.capacity input').val($(e.params.data.element).data('capacity')).attr('readonly', true);
                }
                else {
                    $(this).parents('tr').find('.capacity input').val('').attr('readonly', false);
                }
            }
            else {
                $(this).parents('tr').find('.capacity input').val('').attr('readonly', false);

            }

            $(this).parents('tr').find('.count input').val('');
            $(this).parents('tr').find('.cost input').val('');
        }

        function toggleBillItem() {
            $(this).parents('.bill-item').find('*').prop('disabled', function (i, v) {
                return !v;
            });
            $(this).find('i').toggleClass('fa-toggle-on fa-toggle-off');
        }

        function deleteBillItem() {
            $(this).parents('.bill-item').remove();
        }

        function addNewItem(items, index) {

            var itemId = $('<?php echo e(Form::select('', array_pluck($items, 'name', 'id'), null, ['required', 'placeholder' => __('Select Item') . '...', 'class' => 'form-control select2 items'])); ?>');
            itemId.attr('name', 'billItems[' + index + '][item_id]');

            var tdItemId = $('<td class="item-id"/>').append(itemId);

            var unitId = $('<?php echo e(Form::select('', [], null, ['required', 'placeholder' => __('Select Unit') . '...', 'class' => 'form-control select2 units'])); ?>');
            unitId.attr('name', 'billItems[' + index + '][unit_id]');

            var tdUnitId = $('<td class="unit-id"/>').append(unitId);

            var capacity = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>');
            capacity.attr('name', 'billItems[' + index + '][capacity]');

            var tdcapacity = $('<td class="capacity"/>').append(capacity);

            var count = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Cost') . '...'])); ?>');
            count.attr('name', 'billItems[' + index + '][count]');

            var tdCount = $('<td class="count"/>').append(count);

            var cost = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => 'Enter Cost...'])); ?>');
            cost.attr('name', 'billItems[' + index + '][cost]');

            var tdCost = $('<td class="cost"/>').append(cost);

            var tdTotalCost = $('<td class="total-cost"/>');

            var toggleButton = $('<a class="btn btn-box-tool toggle-item" data-toggle="tooltip" title="Enable / Disable" tabindex="-1"/>')
                .append($('<i class="fa fa-2x fa-toggle-on"/>'));

            var deleteButton = $('<a class="btn btn-box-tool delete-item" data-toggle="tooltip" title="Delete" tabindex="-1"/>')
                .append($('<i class="fa fa-2x fa-times"/>'));

            var tdControlsButton = $('<td/>').append(toggleButton).append(deleteButton);

            var billItem = $('<tr class="bill-item" data-index="' + index + '"/>')
                .append(tdItemId).append(tdUnitId)
                .append(tdcapacity).append(tdCount)
                .append(tdCost).append(tdTotalCost).append(tdControlsButton);

            billItem.appendTo('#bill_items');

            return billItem;
        }

        function billItemFocusIn() {
            var newRow = addNewItem(items, $('.bill-item:last-child').data('index') + 1);

            $('.bill-item').unbind('focusin');
            $('.bill-item:last-child').focusin(billItemFocusIn);

            newRow.find('.select2').select2({
                tags: true,
                createTag: function (params) {
                    return {
                        id: params.term,
                        text: params.term
                    }
                }
            });

            newRow.find('.select2.items').on('select2:select', changeItem);

            newRow.find('.select2.units').on('select2:select', changeUnit);

            newRow.find('.capacity input, .count input, .cost input').keyup(totalCost);

            newRow.find('.toggle-item').click(toggleBillItem);

            newRow.find('.delete-item').click(deleteBillItem);

            newRow.tooltip({
                selector: '.controls *'
            });
        }

        $(function () {
            var index = 0;
            if ($('.bill-item:last-child').length > 0) {
                index = $('.bill-item:last-child').data('index') + 1;
            }
            addNewItem(items, index);

            $('.select2.supplier, .bill-item .select2').select2({
                tags: true,
                createTag: function (params) {
                    return {
                        id: params.term,
                        text: params.term
                    }
                }
            });
            $('.select2.supplier').select2('focus');

            $('.bill-item:last-child').focusin(billItemFocusIn);

            $('.select2.items').on('select2:select', changeItem);

            $('.select2.units').on('select2:select', changeUnit);

            $('#bill input[type="submit"]').click(function (event) {
                $('.bill-item:last-child').remove();
                $('.bill-item:last-child').focusin(billItemFocusIn);
            });

            $('.toggle-item').click(toggleBillItem);

            $('.delete-item').click(deleteBillItem);

            $('.capacity input, .count input, .cost input').keyup(totalCost);
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>