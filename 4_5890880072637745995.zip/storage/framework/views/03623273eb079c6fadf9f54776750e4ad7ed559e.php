<?php $__env->startSection('title', __('Edit Item')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-list"></i> <?php echo e(__('Item')); ?>

                <small><?php echo e(__('Edit')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.items.index')); ?>"><?php echo e(__('Items')); ?></a></li>
                <li class="active"><?php echo e(__('Edit')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Horizontal Form -->
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Edit Item')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <?php echo e(Form::model($item, ['route' => ['dashboard.items.update' , $item->id], 'method' => 'put', 'files' => true, 'id' => 'item', 'autocomplete' => 'off'])); ?>

                        <?php echo e(Form::hidden('id')); ?>

                        <div class="box-body">
                            <div class="form-group <?php echo e($errors->has('name')? 'has-error' : ''); ?>">
                                <?php if($errors->has('name')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('name', __('Name') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::text('name', old('name'), ['required', 'class' => 'form-control', 'placeholder' => __('Enter Item Name') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('description')? 'has-error' : ''); ?>">
                                <?php if($errors->has('description')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('description', __('Description') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control', 'placeholder' => __('Enter Description') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('image')? 'has-error' : ''); ?>">
                                <?php if($errors->has('image')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('image', __('Image') .':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::file('image', old('image'), ['class' => 'form-control'])); ?>

                                <span class="help-block"><?php echo e($errors->first('image')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('notes')? 'has-error' : ''); ?>">
                                <?php if($errors->has('notes')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('notes', __('Notes') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('notes', old('notes'), ['class' => 'form-control', 'placeholder' => __('Enter Notes') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('notes')); ?></span>
                            </div>
                            <table class="table table-hover" id="item_units">
                                <tr>
                                    <th><?php echo e(__('Unit')); ?></th>
                                    <th><?php echo e(__('Capacity')); ?></th>
                                    <th><?php echo e(__('Price')); ?></th>
                                    <th><?php echo e(__('Controls')); ?></th>
                                </tr>
                                <?php if(old('units')): ?>
                                    <?php $__currentLoopData = old('units'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="item-unit" data-index="<?php echo e($index); ?>">

                                            <td class="id <?php echo e($errors->has('units.' . $index . '.name')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::text('units[' . $index . '][name]', $unit['name'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Unit Name') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('units.' . $index . '.name')); ?></span>
                                            </td>
                                            <td class="capacity <?php echo e($errors->has('units.' . $index . '.capacity')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('units[' . $index . '][capacity]', $unit['capacity'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('units.' . $index . '.capacity')); ?></span>

                                            </td>
                                            <td class="price <?php echo e($errors->has('units.' . $index . '.price')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('units[' . $index . '][price]', $unit['price'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Price') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('units.' . $index . '.price')); ?></span>
                                            </td>
                                            <td class="controls">
                                                <a class="btn btn-box-tool toggle-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-toggle-on"></i>
                                                </a>
                                                <a class="btn btn-box-tool delete-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $item->units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="item-unit" data-index="<?php echo e($index); ?>">

                                            <td class="id <?php echo e($errors->has('units.' . $index . '.name')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::text('units[' . $index . '][name]', $unit->name, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Unit Name') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('units.' . $index . '.name')); ?></span>
                                            </td>
                                            <td class="capacity <?php echo e($errors->has('units.' . $index . '.capacity')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('units[' . $index . '][capacity]', $unit->capacity, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('units.' . $index . '.capacity')); ?></span>

                                            </td>
                                            <td class="price <?php echo e($errors->has('units.' . $index . '.price')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('units[' . $index . '][price]', $unit->price, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Price') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('units.' . $index . '.price')); ?></span>
                                            </td>
                                            <td>
                                                <a class="btn btn-box-tool toggle-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-toggle-on"></i>
                                                </a>
                                                <a class="btn btn-box-tool delete-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </table>
                            <div class="text-center <?php echo e($errors->has('units')? 'has-error' : ''); ?>">
                                <h4 class="help-block"><?php echo e($errors->first('units')); ?></h4>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <?php echo e(link_to_route('dashboard.items.index', __('Back'), null, [ 'class' => 'btn btn-default', 'tabindex' => '-1' ])); ?>

                            <?php echo e(Form::submit(__('Update'), ['class' => 'btn btn-primary pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                        <?php echo e(Form::close()); ?>

                    </div>
                    <!-- /.box -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function toggleItemUnit() {
            $(this).parents('.item-unit').find('*').prop('disabled', function (i, v) {
                return !v;
            });
            $(this).find('i').toggleClass('fa-toggle-on fa-toggle-off');
        }

        function deleteItemUnit() {
            $(this).parents('.item-unit').remove();
        }

        function addNewItem(index) {

            var name = $('<?php echo e(Form::text('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Unit Name') . '...'])); ?>');
            name.attr('name', 'units[' + index + '][name]');

            var tdName = $('<td class="id"/>').append(name);

            var capacity = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>');
            capacity.attr('name', 'units[' + index + '][capacity]');

            var tdCapacity = $('<td class="capacity"/>').append(capacity);

            var price = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Price') . '...'])); ?>');
            price.attr('name', 'units[' + index + '][price]');

            var tdPrice = $('<td class="cost"/>').append(price);

            var toggleButton = $('<a class="btn btn-box-tool toggle-item" data-toggle="tooltip" title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1"/>')
                .append($('<i class="fa fa-2x fa-toggle-on"/>'));

            var deleteButton = $('<a class="btn btn-box-tool delete-item" data-toggle="tooltip" title="<?php echo e(__('Delete')); ?>" tabindex="-1"/>')
                .append($('<i class="fa fa-2x fa-times"/>'));

            var tdControlsButton = $('<td class="controls"/>').append(toggleButton).append(deleteButton);

            var itemUnit = $('<tr class="item-unit" data-index="' + index + '"/>')
                .append(tdName).append(tdCapacity)
                .append(tdPrice).append(tdControlsButton);

            itemUnit.appendTo('#item_units');

            return itemUnit;
        }

        function unitFocusIn() {
            var index = 0;

            if ($('.item-unit:last-child').length > 0) {
                index = $('.item-unit:last-child').data('index') + 1;
            }

            var newRow = addNewItem(index);

            $('.item-unit').unbind('focusin');
            $('.item-unit:last-child').focusin(unitFocusIn);

            newRow.find('.toggle-item').click(toggleItemUnit);

            newRow.find('.delete-item').click(deleteItemUnit);

            newRow.tooltip({
                selector: '.controls *'
            });
        }

        $(function () {

            $('.item-unit').focusin(unitFocusIn);

            $('.toggle-item').click(toggleItemUnit);

            $('.delete-item').click(deleteItemUnit);

            unitFocusIn();

            $('#item input[type="submit"]').click(function (event) {
                $('.item-unit:last-child').remove();
                $('.item-unit:last-child').focusin(unitFocusIn);
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>