<?php echo e(Form::model($itemStorageType, ['route' => ['dashboard.items.storageTypes.store', 'id' => $item->id], 'method' => 'post', 'autoComplete' => 'off'])); ?>


<?php echo e(Form::label('name', 'Name:',['required', 'class' => ''])); ?>

<?php echo e(Form::text('name',old('name'), ['required', 'list' => 'storage_types'])); ?>

<?php echo e($errors->first('name')); ?>


<?php echo e(Form::label('count', 'Count:',['required', 'class' => ''])); ?>

<?php echo e(Form::number('count',old('count'), ['required'])); ?>

<?php echo e($errors->first('count')); ?>


<?php echo e(Form::label('price', 'Price:',['required', 'class' => ''])); ?>

<?php echo e(Form::number('price',old('price'), ['required'])); ?>

<?php echo e($errors->first('price')); ?>


<?php echo e(Form::submit('Save', ['class' => ''])); ?>

<?php echo e(Form::close()); ?>


<?php echo e(Form::macro('storageTypes', function($items){

    $res = '';
    foreach ($items as $key => $value) {
        $res .= Form::label("storageTypes[$key][name]", 'Name:',['required', 'class' => '']);
        $res .= Form::text("storageTypes[$key][name]",$value->name, ['list' => 'storage_types']);

        $res .= Form::label("storageTypes[$key][count]", 'Count:',['required', 'class' => '']);
        $res .= Form::number("storageTypes[$key][count]",$value->itemStorageType->count, []);

        $res .= Form::label("storageTypes[$key][price]", 'Price:',['required', 'class' => '']);
        $res .= Form::number("storageTypes[$key][price]",$value->itemStorageType->price, []);
    }
    return $res;
})); ?>


<datalist id='storage_types'>
    <?php $__currentLoopData = $storageTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storageType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php echo e($item->storageTypes->contains('id', $storageType->id)? 'disabled' : ''); ?>><?php echo e($storageType->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
