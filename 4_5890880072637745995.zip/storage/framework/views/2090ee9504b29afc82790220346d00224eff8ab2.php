<?php $__env->startSection('title', __('View Supplier')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-shopping-bag"></i> <?php echo e(__('View Supplier')); ?>

            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.suppliers.index')); ?>"><?php echo e(__('Suppliers')); ?></a></li>
                <li class="active"><?php echo e(__('View')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="row">
                <div class="col-md-4">

                    <!-- Profile Image -->
                    <div class="box box-primary">
                        <div class="box-body box-profile">

                            <h3 class="profile-username text-center"><?php echo e($supplier->company); ?></h3>

                            <p class="text-muted text-center"><?php echo e($supplier->name); ?></p>

                            <a href="<?php echo e(route('dashboard.suppliers.edit', $supplier->id)); ?>"
                               class="btn btn-primary btn-block"><b><i
                                        class="fa fa-pencil-square-o"></i> <?php echo e(__('Edit Supplier')); ?></b></a>

                            <ul class="list-group list-group-unbordered">
                                <li class="list-group-item">
                                    <b><?php echo e(__('Phone')); ?></b> <a class="pull-right"><?php echo e($supplier->phone); ?></a>
                                </li>
                                <li class="list-group-item">
                                    <b><?php echo e(__('Mobile')); ?></b> <a class="pull-right"><?php echo e($supplier->mobile); ?></a>
                                </li>
                                <li class="list-group-item">
                                    <b><?php echo e(__('Balance')); ?></b> <a class="pull-right"><?php echo e($supplier->balance); ?></a>
                                </li>
                            </ul>

                            <a href="<?php echo e(route('dashboard.suppliers.bills.create', $supplier->id)); ?>"
                               class="btn btn-success btn-block"><b><?php echo e(__('Add new Bill')); ?></b></a>
                            <a href="<?php echo e(route('dashboard.suppliers.payments.create', $supplier->id)); ?>"
                               class="btn btn-danger btn-block"><b><?php echo e(__('Add new Payment')); ?></b></a>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->

                    <!-- About Me Box -->
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('About')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <strong><i class="fa fa-map-marker margin-r-5"></i> <?php echo e(__('Address')); ?>:</strong>

                            <p class="text-muted"><?php echo e($supplier->address); ?></p>

                            <hr>

                            <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(__('Notes')); ?>:</strong>

                            <p class="text-muted">
                                <?php echo e($supplier->notes); ?>

                            </p>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
                <div class="col-md-8">
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Supplier Activities')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="tab-pane" id="timeline">
                                <!-- The timeline -->
                                <ul class="timeline timeline-inverse">
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->first || ($event->date != $prevDate)): ?>
                                        <!-- timeline time label -->
                                            <li class="time-label">
                                                <span class="bg-blue">
                                                    <?php echo e(date('D d/m/Y', strtotime($event->date))); ?>

                                                </span>
                                            </li>
                                            <!-- /.timeline-label -->
                                    <?php endif; ?>
                                    <?php if(class_basename($event) == 'Bill'): ?>
                                        <!-- timeline item -->
                                            <li>
                                                <i class="fa fa-truck bg-green"></i>

                                                <div class="timeline-item">
                                                    <span class="time"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(date('h:i A', strtotime($event->time))); ?></span>

                                                    <h3 class="timeline-header">
                                                        <a href="<?php echo e(route('dashboard.bills.show', $event->id)); ?>"><?php echo e(__('Bill')); ?>

                                                            :</a>
                                                        #<?php echo e(str_pad($event->id, 6, "0", STR_PAD_LEFT )); ?>

                                                    </h3>

                                                    <div class="timeline-body">
                                                        <dl>
                                                            <dt><?php echo e(__('Cost')); ?>:</dt>
                                                            <dd><?php echo e($event->cost); ?></dd>
                                                            <dt><?php echo e(__('Items Count')); ?>:</dt>
                                                            <dd><?php echo e($event->items->count()); ?> <?php echo e(__('Item(s)')); ?></dd>
                                                            <dt><?php echo e(__('Notes')); ?>:</dt>
                                                            <dd><?php echo e($event->notes); ?></dd>
                                                        </dl>
                                                    </div>
                                                    <div class="timeline-footer">
                                                        <a href="<?php echo e(route('dashboard.bills.edit', $event->id)); ?>"
                                                           class="btn btn-primary btn-xs"><?php echo e(__('Edit')); ?></a>
                                                        <a href="<?php echo e(route('dashboard.bills.print', $event->id)); ?>"
                                                           target="_blank"
                                                           class="btn btn-warning btn-xs"><?php echo e(__('Print')); ?></a>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- END timeline item -->
                                    <?php else: ?>
                                        <!-- timeline item -->
                                            <li>
                                                <i class="fa fa-credit-card bg-red"></i>

                                                <div class="timeline-item">
                                                    <span class="time"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(date('h:i A', strtotime($event->time))); ?></span>

                                                    <h3 class="timeline-header">
                                                        <a href="<?php echo e(route('dashboard.supplierPayments.show', $event->id)); ?>"><?php echo e(__('Payment')); ?>

                                                            :</a>
                                                        #<?php echo e(str_pad($event->id, 6, "0", STR_PAD_LEFT )); ?>

                                                    </h3>
                                                    <div class="timeline-body">
                                                        <dl>
                                                            <dt><?php echo e(__('Amount')); ?>:</dt>
                                                            <dd><?php echo e($event->amount); ?></dd>
                                                            <dt><?php echo e(__('Notes')); ?>:</dt>
                                                            <dd><?php echo e($event->notes); ?></dd>
                                                        </dl>
                                                    </div>
                                                    <div class="timeline-footer">
                                                        <a href="<?php echo e(route('dashboard.supplierPayments.edit', $event->id)); ?>"
                                                           class="btn btn-primary btn-xs"><?php echo e(__('Edit')); ?></a>
                                                        <a href="<?php echo e(route('dashboard.supplierPayments.print', $event->id)); ?>"
                                                           target="_blank"
                                                           class="btn btn-warning btn-xs"><?php echo e(__('Print')); ?></a>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- END timeline item -->
                                        <?php endif; ?>
                                        <?php
                                            $prevDate = $event->date;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <i class="fa fa-clock-o bg-gray"></i>
                                    </li>
                                </ul>
                            </div>
                            <!-- /.tab-pane -->
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>