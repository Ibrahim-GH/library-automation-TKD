<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?> " dir="<?php echo e(app()->getLocale() == 'ar'? 'rtl' :'ltr'); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <?php echo $__env->yieldContent('head'); ?>

    <link href="https://fonts.googleapis.com/css?family=Tajawal" rel="stylesheet">
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('AdminLTE/bower_components/jquery/dist/jquery.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
