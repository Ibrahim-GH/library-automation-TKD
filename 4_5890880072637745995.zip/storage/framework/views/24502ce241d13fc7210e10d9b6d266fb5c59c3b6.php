<?php $__env->startSection('title', __('View Bill')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="invoice">
        <!-- title row -->
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    <i class="fa fa-pencil"></i> <?php echo e(config('app.name')); ?>, Com.
                    <small class="pull-right"><?php echo e(__('Date')); ?>: <?php echo e(date('d/m/Y')); ?></small>
                </h2>
            </div>
            <!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
                <?php echo e(__('From')); ?>

                <address>
                    <strong><?php echo e($bill->supplier->company); ?></strong><br>
                    <?php echo e($bill->supplier->address); ?><br>
                    <?php echo e(__('Phone')); ?>: <?php echo e($bill->supplier->phone); ?><br>
                    <?php echo e(__('Mobile')); ?>: <?php echo e($bill->supplier->mobile); ?><br>
                </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                <?php echo e(__('To')); ?>

                <address>
                    <strong><?php echo e(config('app.name')); ?>, Com.</strong><br>
                    <?php echo e(config('app.address')); ?><br>
                    <?php echo e(__('Phone')); ?>: <?php echo e(config('app.phone')); ?><br>
                    <?php echo e(__('Email')); ?>: <?php echo e(config('app.email')); ?>

                </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                <b><?php echo e(__('Bill')); ?> #<?php echo e(str_pad($bill->id, 6, "0", STR_PAD_LEFT )); ?></b><br>
                <br>
                <b><?php echo e(__('Order ID')); ?>:</b> 4F3S8J<br>
                <b><?php echo e(__('Receive Date')); ?>:</b> <?php echo e(date('d/m/Y', strtotime($bill->date))); ?><br>
                <b><?php echo e(__('Total Cost')); ?>:</b> <?php echo e($bill->cost); ?>

            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->

        <!-- Table row -->
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th><?php echo e(__('Item')); ?></th>
                        <th><?php echo e(__('Unit')); ?></th>
                        <th><?php echo e(__('Capacity')); ?></th>
                        <th><?php echo e(__('Count')); ?></th>
                        <th><?php echo e(__('Cost')); ?></th>
                        <th><?php echo e(__('Subtotal')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $bill->billItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($billItem->item->name); ?></td>
                            <td><?php echo e($billItem->unit->name); ?></td>
                            <td><?php echo e($billItem->unit->capacity); ?></td>
                            <td><?php echo e($billItem->count); ?></td>
                            <td><?php echo e($billItem->cost); ?></td>
                            <td><?php echo e($billItem->unit->capacity * $billItem->count * $billItem->cost); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>