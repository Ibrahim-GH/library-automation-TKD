<?php $__env->startSection('title', __('View Item')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-list"></i> <?php echo e(__('View Item')); ?>

            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.items.index')); ?>"><?php echo e(__('Items')); ?></a></li>
                <li class="active"><?php echo e(__('View')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="row">
                <div class="col-md-4">

                    <!-- Profile Image -->
                    <div class="box box-primary">
                        <div class="box-body box-profile">
                            <?php if(isset($item->image)): ?>
                                <?php echo e(Html::image($item->image, $item->name, array('class' => ' img-responsive'))); ?>

                            <?php endif; ?>
                            <h3 class="profile-username text-center"><?php echo e($item->name); ?></h3>

                            <p class="text-muted text-center"><?php echo e($item->description); ?></p>

                            <a href="<?php echo e(route('dashboard.items.edit', $item->id)); ?>" class="btn btn-primary btn-block">
                                <b>
                                    <i class="fa fa-pencil-square-o"></i> <?php echo e(__('Edit Item')); ?>

                                </b>
                            </a>

                            <table id="data_table" align="center" class="table table-borderless table-hover list-group">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('Unit')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Count')); ?></th>
                                    <th><?php echo e(__('Price')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $item->units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($unit->name); ?></td>
                                        <td><?php echo e($item->amount / $unit->capacity); ?></td>
                                        <td><?php echo e($unit->capacity); ?></td>
                                        <td><?php echo e($unit->price * $unit->capacity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->

                    <!-- About Me Box -->
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(__('Notes')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <p><?php echo e($item->notes); ?></p>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
                <div class="col-md-8">
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Item Activities')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="tab-pane" id="timeline">
                                <!-- The timeline -->
                                <ul class="timeline timeline-inverse">
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->first || ($event->date != $prevDate)): ?>
                                        <!-- timeline time label -->
                                            <li class="time-label">
                                                <span class="bg-blue">
                                                    <?php echo e(date('D d/m/Y', strtotime($event->date))); ?>

                                                </span>
                                            </li>
                                            <!-- /.timeline-label -->
                                    <?php endif; ?>
                                    <?php
                                        $eventItem = $event->items()->find($item->id);
                                    ?>
                                    <?php if(class_basename($event) == 'Bill'): ?>
                                        <!-- timeline item -->
                                            <li>
                                                <i class="fa fa-sign-in bg-green"></i>

                                                <div class="timeline-item">
                                                    <span class="time"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(date('h:i A', strtotime($event->time))); ?></span>

                                                    <h3 class="timeline-header">
                                                        <a href="<?php echo e(route('dashboard.bills.show', $event->id)); ?>"><?php echo e(__('Bill')); ?>

                                                            :</a>
                                                        #<?php echo e(str_pad($event->id, 6, "0", STR_PAD_LEFT )); ?>

                                                    </h3>

                                                    <div class="timeline-body">
                                                        <dl class="dl-horizontal">
                                                            <dt><?php echo e(__('Supplier Name')); ?>:</dt>
                                                            <dd><?php echo e($event->supplier->company); ?></dd>
                                                            <dt><?php echo e(__('Item Count')); ?>:</dt>
                                                            <dd><?php echo e($eventItem->billItem->count); ?> <?php echo e($eventItem->billItem->unit->name); ?></dd>
                                                            <dt><?php echo e(__('Cost')); ?>:</dt>
                                                            <dd><?php echo e($eventItem->billItem->cost); ?></dd>
                                                            <dt><?php echo e(__('Total Cost')); ?>:</dt>
                                                            <dd><?php echo e($eventItem->billItem->unit->capacity * $eventItem->billItem->count * $eventItem->billItem->cost); ?></dd>
                                                            <dt><?php echo e(__('Notes')); ?>:</dt>
                                                            <dd><?php echo e($event->notes); ?></dd>
                                                        </dl>
                                                    </div>
                                                    <div class="timeline-footer">
                                                        <a href="<?php echo e(route('dashboard.bills.edit', $event->id)); ?>"
                                                           class="btn btn-primary btn-xs"><?php echo e(__('Edit')); ?></a>
                                                        <a href="<?php echo e(route('dashboard.bills.print', $event->id)); ?>"
                                                           target="_blank"
                                                           class="btn btn-warning btn-xs"><?php echo e(__('Print')); ?></a>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- END timeline item -->
                                    <?php else: ?>
                                        <!-- timeline item -->
                                            <li>
                                                <i class="fa fa-sign-out bg-red"></i>

                                                <div class="timeline-item">
                                                    <span class="time"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(date('h:i A', strtotime($event->time))); ?></span>

                                                    <h3 class="timeline-header">
                                                        <a href="<?php echo e(route('dashboard.supplierPayments.show', $event->id)); ?>"><?php echo e(__('Order')); ?>

                                                            :</a>
                                                        #<?php echo e(str_pad($event->id, 6, "0", STR_PAD_LEFT )); ?>

                                                    </h3>
                                                    <div class="timeline-body">
                                                        <dl class="dl-horizontal">
                                                            <dt><?php echo e(__('Customer Name')); ?>:</dt>
                                                            <dd><?php echo e($event->customer->company); ?></dd>
                                                            <dt><?php echo e(__('Item Count')); ?>:</dt>
                                                            <dd><?php echo e($eventItem->orderItem->count); ?> <?php echo e($eventItem->orderItem->unit->name); ?></dd>
                                                            <dt><?php echo e(__('Cost')); ?>:</dt>
                                                            <dd><?php echo e($eventItem->orderItem->cost); ?></dd>
                                                            <dt><?php echo e(__('Total Cost')); ?>:</dt>
                                                            <dd><?php echo e($eventItem->orderItem->unit->capacity * $eventItem->orderItem->count * $eventItem->orderItem->cost); ?></dd>
                                                            <dt><?php echo e(__('Notes')); ?>:</dt>
                                                            <dd><?php echo e($event->notes); ?></dd>
                                                        </dl>
                                                    </div>
                                                    <div class="timeline-footer">
                                                        <a href="<?php echo e(route('dashboard.orders.edit', $event->id)); ?>"
                                                           class="btn btn-primary btn-xs"><?php echo e(__('Edit')); ?></a>
                                                        <a href="<?php echo e(route('dashboard.orders.print', $event->id)); ?>"
                                                           target="_blank"
                                                           class="btn btn-warning btn-xs"><?php echo e(__('Print')); ?></a>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- END timeline item -->
                                        <?php endif; ?>
                                        <?php
                                            $prevDate = $event->date;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <i class="fa fa-clock-o bg-gray"></i>
                                    </li>
                                </ul>
                            </div>
                            <!-- /.tab-pane -->
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>