<?php $__env->startSection('title', __('Items')); ?>

<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link rel="stylesheet"
          href="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/css/dataTables.bootstrap.' . app()->getLocale() . '.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-list"></i> <?php echo e(__('Items')); ?>

                <small><?php echo e(__('All Items')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li class="active"><?php echo e(__('Items')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">
                                <?php echo e(link_to_route('dashboard.items.create', __('Create New Item'), null, ['class' => 'btn btn-success'])); ?>

                            </h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="data_table" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Notes')); ?></th>
                                    <th><?php echo e(__('Controls')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->amount); ?></td>
                                        <td><?php echo e($item->notes); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('dashboard.items.show', $item->id)); ?>"
                                               class="btn btn-box-tool" data-toggle="tooltip" title="<?php echo e(__('View')); ?>">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('dashboard.items.edit', $item->id)); ?>"
                                               class="btn btn-box-tool" data-toggle="tooltip" title="<?php echo e(__('Edit')); ?>">
                                                <i class="fa fa-pencil-square-o"></i>
                                            </a>
                                            <?php if(!$item->deleted_at): ?>
                                                <?php echo e(Form::open(['route' => ['dashboard.items.destroy', $item->id], 'method' => 'delete', 'class' => 'inline'])); ?>

                                                <button type="submit" class="btn btn-box-tool" data-toggle="tooltip"
                                                        title="<?php echo e(__('Delete')); ?>"
                                                        onclick="return confirm(' <?php echo e(__('Do you want to delete this Item')); ?> ')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                                <?php echo e(Form::close()); ?>

                                            <?php else: ?>
                                                <?php echo e(Form::open(['route' => ['dashboard.items.restore', 'id' => $item->id ], 'method' => 'post', 'class' => 'inline'])); ?>

                                                <button type="submit" class="btn btn-box-tool" data-toggle="tooltip"
                                                        title="<?php echo e(__('Restore')); ?>"
                                                        onclick="return confirm(' <?php echo e(__('Do you want to restore this Item')); ?> ')">
                                                    <i class="fa fa-undo"></i>
                                                </button>
                                                <?php echo e(Form::close()); ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('forceDelete', $item)): ?>
                                                    <?php echo e(Form::open(['route' => ['dashboard.items.forceDelete', 'id' => $item->id ], 'method' => 'post', 'class' => 'inline'])); ?>

                                                    <button type="submit" class="btn btn-box-tool" data-toggle="tooltip"
                                                            title="<?php echo e(__('Force Delete')); ?>"
                                                            onclick="return confirm(' <?php echo e(__('Do you want to force delete this Item')); ?> ')">
                                                        <i class="fa fa-times"></i>
                                                    </button>
                                                    <?php echo e(Form::close()); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Notes')); ?></th>
                                    <th><?php echo e(__('Controls')); ?></th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- page script -->
    <script>
        $(function () {
            $('#data_table').DataTable({
                'paging': true,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'order': [],
                'info': true,
                'autoWidth': false,
                "columns": [
                    null,
                    null,
                    null,
                    {"orderable": false}
                ]
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>