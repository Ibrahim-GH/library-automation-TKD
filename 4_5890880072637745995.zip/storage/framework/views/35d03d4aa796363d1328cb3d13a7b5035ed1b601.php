<?php $__env->startSection('title', __('Edit Customer')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-users"></i> <?php echo e(__('Customer')); ?>

                <small><?php echo e(__('Edit')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.customers.index')); ?>"><?php echo e(__('Customers')); ?></a></li>
                <li class="active"><?php echo e(__('Edit')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Horizontal Form -->
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Edit Customer')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <?php echo e(Form::model($customer, ['route' => ['dashboard.customers.update', $customer->id], 'method' => 'put', 'autocomplete' => 'off'])); ?>

                        <?php echo e(Form::hidden('id')); ?>

                        <div class="box-body">
                            <div class="form-group <?php echo e($errors->has('company')? 'has-error' : ''); ?>">
                                <?php if($errors->has('company')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('company', __('Company') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::text('company', old('company'), ['required', 'class' => 'form-control', 'placeholder' => __('Enter Company Name') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('company')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('name')? 'has-error' : ''); ?>">
                                <?php if($errors->has('name')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('name', __('Name') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::text('name', old('name'), ['class' => 'form-control', 'placeholder' => __('Enter Customer Name') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('phone')? 'has-error' : ''); ?>">
                                <?php if($errors->has('phone')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('phone', __('Phone') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::text('phone', old('phone'), ['class' => 'form-control', 'placeholder' => __('Enter Phone Number') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('phone')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('mobile')? 'has-error' : ''); ?>">
                                <?php if($errors->has('mobile')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('mobile', __('Mobile') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::text('mobile', old('mobile'), ['class' => 'form-control', 'placeholder' => __('Enter Mobile Number') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('mobile')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('address')? 'has-error' : ''); ?>">
                                <?php if($errors->has('address')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('address', __('Address') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('address', old('address'), ['class' => 'form-control', 'placeholder' => __('Enter Address') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('address')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('notes')? 'has-error' : ''); ?>">
                                <?php if($errors->has('notes')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('notes', __('Notes') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('notes', old('notes'), ['class' => 'form-control', 'placeholder' => __('Enter Notes') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('notes')); ?></span>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <?php echo e(link_to_route('dashboard.customers.index', __('Back'), null, [ 'class' => 'btn btn-default', 'tabindex' => '-1' ])); ?>

                            <?php echo e(Form::submit(__('Edit'), ['class' => 'btn btn-primary pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                        <?php echo e(Form::close()); ?>

                    </div>
                    <!-- /.box -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>