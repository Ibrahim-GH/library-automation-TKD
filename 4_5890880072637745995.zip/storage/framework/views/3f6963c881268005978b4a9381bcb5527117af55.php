<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('head'); ?>
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins/iCheck/flat/green.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="login-box">
        <div class="login-logo">
            <a href="../../index2.html"><b><?php echo e(__('TKD')); ?></b> <?php echo e(__('Stationery')); ?></a>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
            <p class="login-box-msg"><?php echo e(__('Sign in to start your session')); ?></p>
            <?php echo e(Form::open(['route' => ['login'], 'method' => 'post'])); ?>

                <div class="form-group has-feedback">
                    <?php echo e(Form::email('email', old('email'), ['autofocus', 'required', 'class' => 'form-control', 'placeholder' => 'Email'])); ?>

                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <?php echo e(Form::password('password',['required', 'class' => 'form-control', 'placeholder' => 'Password'])); ?>

                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-xs-7">
                        <div class="checkbox icheck">
                            <label>
                                <?php echo e(Form::checkbox('remember', null, old('remember') ? 'checked' : '')); ?> <?php echo e(__('Remember Me')); ?>

                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-5">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">
                            <?php echo e(__('Sign In')); ?>

                        </button>
                    </div>
                    <!-- /.col -->
                </div>
            <?php echo e(Form::close()); ?>

            <a href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('I forgot my password')); ?>

            </a><br>

        </div>
        <!-- /.login-box-body -->
    </div>
    <!-- /.login-box -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- iCheck -->
    <script src="<?php echo e(asset('AdminLTE/plugins/iCheck/icheck.min.js')); ?>"></script>
    <script>
        $(function () {
            $('input').iCheck({
                checkboxClass: 'icheckbox_flat-green',
                radioClass: 'iradio_flat-green',
                increaseArea: '20%' /* optional */
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>