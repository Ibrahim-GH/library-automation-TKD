<?php $__env->startSection('title', 'Edit Order'); ?>

<?php $__env->startSection('head'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-shopping-cart"></i> <?php echo e(__('Order')); ?>

                <small><?php echo e(__('Edit')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.orders.index')); ?>"><?php echo e(__('Orders')); ?></a></li>
                <li class="active"><?php echo e(__('Edit')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Horizontal Form -->
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Edit Order')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <?php echo e(Form::model($order, ['route' => ['dashboard.orders.update', $order->id], 'method' => 'put', 'id' => 'order'])); ?>

                        <?php echo e(Form::hidden('id')); ?>

                        <div class="box-body">
                            <div class="form-group <?php echo e($errors->has('customer_id')? 'has-error' : ''); ?>">
                                <?php if($errors->has('customer_id')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('customer_id', __('Customer') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::select('customer_id', $customers, null, ['required', 'class' => 'form-control select2 customer', 'placeholder' => __('Select Customer') . '...' ])); ?>

                                <span class="help-block"><?php echo e($errors->first('customer_id')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('date')? 'has-error' : ''); ?>">
                                <?php if($errors->has('date')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('date', __('Date') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::date('date', old('date'), ['required', 'class' => 'form-control', 'placeholder' => __('Select Date') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('time')? 'has-error' : ''); ?>">
                                <?php if($errors->has('time')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('time', __('Time') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::time('time', old('time'), ['required', 'class' => 'form-control', 'placeholder' => __('Select Time') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('time')); ?></span>
                            </div>
                            <table class="table table-hover" id="order_items">
                                <tr>
                                    <th><?php echo e(__('Item')); ?></th>
                                    <th><?php echo e(__('Unit')); ?></th>
                                    <th><?php echo e(__('Capacity')); ?></th>
                                    <th><?php echo e(__('Count')); ?></th>
                                    <th><?php echo e(__('Cost')); ?></th>
                                    <th><?php echo e(__('Total Cost')); ?></th>
                                    <th><?php echo e(__('Controls')); ?></th>
                                </tr>

                                <?php if(old('orderItems')): ?>
                                    <?php $__currentLoopData = old('orderItems'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="order-item" data-index="<?php echo e($index); ?>">
                                            <td class="item-id <?php echo e($errors->has('orderItems.' . $index . '.item_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('orderItems[' . $index . '][item_id]', array_pluck($items, 'name', 'id'), $orderItem['item_id'], ['required', 'placeholder' => __('Select Item') . '...', 'class' => 'form-control select2 items'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.item_id')); ?></span>
                                            </td>
                                            <td class="unit-id <?php echo e($errors->has('orderItems.' . $index . '.unit_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('orderItems[' . $index . '][unit_id]', array_pluck($items->find($orderItem['item_id'])->units, 'name', 'id'), $orderItem['unit_id'], ['required', 'placeholder' => __('Select Unit') . '...', 'class' => 'form-control select2 units'], $unitsOptions)); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.unit_id')); ?></span>
                                            </td>
                                            <td class="capacity <?php echo e($errors->has('orderItems.' . $index . '.capacity')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('orderItems[' . $index . '][capacity]', $orderItem['capacity'], ['required', is_numeric($orderItem['unit_id']) ? 'readonly' : '', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.capacity')); ?></span>

                                            </td>
                                            <td class="count <?php echo e($errors->has('orderItems.' . $index . '.count')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('orderItems[' . $index . '][count]', $orderItem['count'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Count') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.count')); ?></span>

                                            </td>
                                            <td class="cost <?php echo e($errors->has('orderItems.' . $index . '.cost')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('orderItems[' . $index . '][cost]', $orderItem['cost'], ['required', 'class' => 'form-control', 'placeholder' => __('Enter Cost') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.cost')); ?></span>
                                            </td>
                                            <td class="total-cost">
                                                <?php echo e($orderItem['capacity'] * $orderItem['count'] * $orderItem['cost']); ?>

                                            </td>
                                            <td class="controls">
                                                <a class="btn btn-box-tool toggle-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-toggle-on"></i>
                                                </a>
                                                <a class="btn btn-box-tool delete-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="order-item" data-index="<?php echo e($index); ?>">
                                            <td class="item-id <?php echo e($errors->has('orderItems.' . $index . '.item_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('orderItems[' . $index . '][item_id]', array_pluck($items, 'name', 'id'), $orderItem->item_id, ['required', 'placeholder' => __('Select Item') . '...', 'class' => 'form-control select2 items'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.item_id')); ?></span>
                                            </td>
                                            <td class="unit-id <?php echo e($errors->has('orderItems.' . $index . '.unit_id')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::select('orderItems[' . $index . '][unit_id]', array_pluck($items->find($orderItem['item_id'])->units, 'name', 'id'), $orderItem->unit_id, ['required', 'placeholder' => __('Select Unit') . '...', 'class' => 'form-control select2 units'], $unitsOptions)); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.unit_id')); ?></span>
                                            </td>
                                            <td class="capacity <?php echo e($errors->has('orderItems.' . $index . '.capacity')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('orderItems[' . $index . '][capacity]', $orderItem->unit->capacity, ['required', 'readonly', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.capacity')); ?></span>

                                            </td>
                                            <td class="count <?php echo e($errors->has('orderItems.' . $index . '.count')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('orderItems[' . $index . '][count]', $orderItem->count, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Count') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.count')); ?></span>

                                            </td>
                                            <td class="cost <?php echo e($errors->has('orderItems.' . $index . '.cost')? 'has-error' : ''); ?>">
                                                <?php echo e(Form::number('orderItems[' . $index . '][cost]', $orderItem->cost, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Cost') . '...'])); ?>

                                                <span
                                                    class="help-block"><?php echo e($errors->first('orderItems.' . $index . '.cost')); ?></span>
                                            </td>
                                            <td class="total-cost">
                                                <?php echo e($orderItem->unit->capacity * $orderItem->count * $orderItem->cost); ?>

                                            </td>
                                            <td class="controls">
                                                <a class="btn btn-box-tool toggle-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Enable / Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-toggle-on"></i>
                                                </a>
                                                <a class="btn btn-box-tool delete-item" data-toggle="tooltip"
                                                   title="<?php echo e(__('Disable')); ?>" tabindex="-1">
                                                    <i class="fa fa-2x fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php endif; ?>
                            </table>
                            <div class="text-center <?php echo e($errors->has('orderItems')? 'has-error' : ''); ?>">
                                <h4 class="help-block"><?php echo e($errors->first('orderItems')); ?></h4>
                            </div>
                            <div class="form-group <?php echo e($errors->has('notes')? 'has-error' : ''); ?>">
                                <?php if($errors->has('notes')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('notes', 'Notes:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('notes', old('notes'), ['class' => 'form-control', 'placeholder' => 'Enter notes...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('notes')); ?></span>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <?php echo e(link_to_route('dashboard.orders.index', __('Back'), null, [ 'class' => 'btn btn-default', 'tabindex' => '-1' ])); ?>

                            <?php echo e(Form::submit('Update', ['class' => 'btn btn-primary pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                        <?php echo e(Form::close()); ?>

                    </div>
                    <!-- /.box -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('AdminLTE/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        let items = <?php echo json_encode($items, 15, 512) ?>;

        function totalCost() {
            var capacity = $(this).parents('.order-item').find('.capacity input').val();
            var count = $(this).parents('.order-item').find('.count input').val();
            var cost = $(this).parents('.order-item').find('.cost input').val();
            $(this).parents('.order-item').find('.total-cost').html(capacity * count * cost);
        }

        function changeItem(e) {
            $(this).parents('tr').find('.capacity input, .count input, .cost input').val('');

            var item = items.find(x => x.id == e.params.data.id);

            if (item) {
                var units = $(this).parents('tr').find('.select2.units').html($('<option selected value/>').text('<?php echo e(__('Select Unit')); ?>...'));

                item.units.forEach(function (unit) {
                    units.append($('<option value="' + unit.id + '" data-capacity="' + unit.capacity + '" data-price="' + unit.price + '" data-item-id="' + item.id + '"/>').text(unit.name));
                });
            }
            else {
                var units = $(this).parents('tr').find('.select2.units').html($('<option selected value/>').text('<?php echo e(__('Select Unit')); ?>...'));
            }
        }

        function changeUnit(e) {

            var item = items.find(x => x.id == $(e.params.data.element).data('item-id'));

            if (item) {

                var unit = item.units.find(x => x.id == e.params.data.id);

                if (unit) {
                    $(this).parents('tr').find('.capacity input').val($(e.params.data.element).data('capacity')).attr('readonly', true);
                    $(this).parents('tr').find('.cost input').val($(e.params.data.element).data('price'));

                }
                else {
                    $(this).parents('tr').find('.capacity input').val('').attr('readonly', false);
                    $(this).parents('tr').find('.cost input').val('');
                }
            }
            else {
                $(this).parents('tr').find('.capacity input').val('').attr('readonly', false);
                $(this).parents('tr').find('.cost input').val('');
            }

            $(this).parents('tr').find('.count input').val('');
        }

        function toggleOrderItem() {
            $(this).parents('.order-item').find('*').prop('disabled', function (i, v) {
                return !v;
            });
            $(this).find('i').toggleClass('fa-toggle-on fa-toggle-off');
        }

        function deleteOrderItem() {
            $(this).parents('.order-item').remove();
        }

        function addNewItem(items, index) {

            var itemId = $('<?php echo e(Form::select('', array_pluck($items, 'name', 'id'), null, ['required', 'placeholder' => __('Select Item') . '...', 'class' => 'form-control select2 items'])); ?>');
            itemId.attr('name', 'orderItems[' + index + '][item_id]');

            var tdItemId = $('<td class="item-id"/>').append(itemId);

            var unitId = $('<?php echo e(Form::select('', [], null, ['required', 'placeholder' => __('Select Unit') . '...', 'class' => 'form-control select2 units'])); ?>');
            unitId.attr('name', 'orderItems[' + index + '][unit_id]');

            var tdUnitId = $('<td class="unit-id"/>').append(unitId);

            var capacity = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Capacity') . '...'])); ?>');
            capacity.attr('name', 'orderItems[' + index + '][capacity]');

            var tdcapacity = $('<td class="capacity"/>').append(capacity);

            var count = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => __('Enter Cost') . '...'])); ?>');
            count.attr('name', 'orderItems[' + index + '][count]');

            var tdCount = $('<td class="count"/>').append(count);

            var cost = $('<?php echo e(Form::number('', null, ['required', 'class' => 'form-control', 'placeholder' => 'Enter Cost...'])); ?>');
            cost.attr('name', 'orderItems[' + index + '][cost]');

            var tdCost = $('<td class="cost"/>').append(cost);

            var tdTotalCost = $('<td class="total-cost"/>');

            var toggleButton = $('<a class="btn btn-box-tool toggle-item" data-toggle="tooltip" title="Enable / Disable" tabindex="-1"/>')
                .append($('<i class="fa fa-2x fa-toggle-on"/>'));

            var deleteButton = $('<a class="btn btn-box-tool delete-item" data-toggle="tooltip" title="Delete" tabindex="-1"/>')
                .append($('<i class="fa fa-2x fa-times"/>'));

            var tdControlsButton = $('<td/>').append(toggleButton).append(deleteButton);

            var orderItem = $('<tr class="order-item" data-index="' + index + '"/>')
                .append(tdItemId).append(tdUnitId)
                .append(tdcapacity).append(tdCount)
                .append(tdCost).append(tdTotalCost).append(tdControlsButton);

            orderItem.appendTo('#order_items');

            return orderItem;
        }

        function orderItemFocusIn() {
            var newRow = addNewItem(items, $('.order-item:last-child').data('index') + 1);

            $('.order-item').unbind('focusin');
            $('.order-item:last-child').focusin(orderItemFocusIn);

            newRow.find('.select2').select2({
                tags: true,
                createTag: function (params) {
                    return {
                        id: params.term,
                        text: params.term
                    }
                }
            });

            newRow.find('.select2.items').on('select2:select', changeItem);

            newRow.find('.select2.units').on('select2:select', changeUnit);

            newRow.find('.capacity input, .count input, .cost input').keyup(totalCost);

            newRow.find('.toggle-item').click(toggleOrderItem);

            newRow.find('.delete-item').click(deleteOrderItem);

            newRow.tooltip({
                selector: '.controls *'
            });
        }

        $(function () {
            var index = 0;
            if ($('.order-item:last-child').length > 0) {
                index = $('.order-item:last-child').data('index') + 1;
            }
            addNewItem(items, index);

            $('.select2.customer, .order-item .select2').select2({
                tags: true,
                createTag: function (params) {
                    return {
                        id: params.term,
                        text: params.term
                    }
                }
            });
            $('.select2.customer').select2('focus');

            $('.order-item:last-child').focusin(orderItemFocusIn);

            $('.select2.items').on('select2:select', changeItem);

            $('.select2.units').on('select2:select', changeUnit);

            $('#order input[type="submit"]').click(function (event) {
                $('.order-item:last-child').remove();
                $('.order-item:last-child').focusin(orderItemFocusIn);
            });

            $('.toggle-item').click(toggleOrderItem);

            $('.delete-item').click(deleteOrderItem);

            $('.capacity input, .count input, .cost input').keyup(totalCost);
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>