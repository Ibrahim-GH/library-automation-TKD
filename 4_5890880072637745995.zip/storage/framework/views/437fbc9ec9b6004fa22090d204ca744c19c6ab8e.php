
<?php echo e(Form::model($storageType, ['route' => ['unit.store'], 'method' => 'post'])); ?>


<?php echo e(Form::label('name', 'Name:',['required', 'class' => ''])); ?>

<?php echo e(Form::text('name',old('name'), ['required', 'list' => 'storage_types'])); ?>

<?php echo e($errors->first('name')); ?>


<?php echo e(Form::label('count', 'Count:',['required', 'class' => ''])); ?>

<?php echo e(Form::number('count',old('count'), ['required'])); ?>

<?php echo e($errors->first('count')); ?>


<?php echo e(Form::label('price', 'Price:',['required', 'class' => ''])); ?>

<?php echo e(Form::number('price',old('price'), ['required'])); ?>

<?php echo e($errors->first('price')); ?>


<?php echo e(Form::submit('Save', ['class' => ''])); ?>

<?php echo e(Form::close()); ?>

