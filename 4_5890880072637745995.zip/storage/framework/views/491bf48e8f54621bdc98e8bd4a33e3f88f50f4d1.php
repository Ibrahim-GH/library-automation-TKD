<?php $__env->startSection('title', 'Create New Item Unit'); ?>

<?php $__env->startSection('head'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-credit-card-alt"></i> <?php echo e(__('Item Unit')); ?>

                <small><?php echo e(__('Create')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.itemUnits.index')); ?>"><?php echo e(__('Item Units')); ?></a></li>
                <li class="active"><?php echo e(__('Create')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Horizontal Form -->
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Create New Item Unit')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <?php echo e(Form::model($itemUnit, ['route' => ['dashboard.supplierPayments.store'], 'method' => 'post'])); ?>

                        <div class="box-body">
                            <div class="form-group <?php echo e($errors->has('item_id')? 'has-error' : ''); ?>">
                                <?php if($errors->has('item_id')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('item_id', 'Item:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::select('item_id', $units, null, ['required', $itemUnit->item_id? 'readonly':'', 'class' => 'form-control select2 items', 'placeholder' => 'Select Item...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('unit_id')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('unit_id')? 'has-error' : ''); ?>">
                                <?php if($errors->has('unit_id')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('unit_id', 'Unit:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::select('unit_id', $units, null, ['required', $itemUnit->unit_id? 'readonly':'', 'class' => 'form-control select2 units', 'placeholder' => 'Select Unit...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('unit_id')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('count')? 'has-error' : ''); ?>">
                                <?php if($errors->has('count')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('count', 'Count:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::number('count', old('date'), ['required', 'class' => 'form-control', 'placeholder' => 'Select Count...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('count')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('price')? 'has-error' : ''); ?>">
                                <?php if($errors->has('price')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('price', 'Price:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::time('price', old('price'), ['required', 'class' => 'form-control', 'placeholder' => 'Select Price...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('price')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('amount')? 'has-error' : ''); ?>">
                                <?php if($errors->has('amount')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('amount', 'Amount:', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::number('amount', old('amount'), ['required', 'class' => 'form-control', 'placeholder' => 'Enter Amount...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <?php echo e(link_to_route('dashboard.supplierPayments.index', __('Back'), null, [ 'class' => 'btn btn-default' ])); ?>

                            <?php echo e(Form::submit('Store', ['class' => 'btn btn-primary pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                        <?php echo e(Form::close()); ?>

                    </div>
                    <!-- /.box -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('AdminLTE/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        $(function () {
            $('.select2.items').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>