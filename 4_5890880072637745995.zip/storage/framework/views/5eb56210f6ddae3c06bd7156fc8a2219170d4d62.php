<?php $__env->startSection('title', __('Test')); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins/metro/css/metro-all.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.metroui.org.ua/v4/css/metro-all.min.css">


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<h1 class="text-center">Metro 4</h1>
<h3 class="text-center">The Components Library</h3>
<div data-role="cube"></div>
<ul data-role="treeview">
    <li>
        <input type="checkbox" data-role="checkbox" data-caption="Play video" title="">
        <ul>
            <li><input type="checkbox" data-role="checkbox" data-caption="AVI" title=""></li>
            <li><input type="checkbox" data-role="checkbox" data-caption="MPEG" title=""></li>
            <li><input checked type="checkbox" data-role="checkbox" data-caption="VIDX" title=""></li>
            <li><input type="checkbox" data-role="checkbox" data-caption="MP4" title=""></li>
            <li><input checked type="checkbox" data-role="checkbox" data-caption="XVID" title=""></li>
        </ul>
    </li>
    <li><input type="checkbox" data-role="checkbox" data-caption="Play audio" title=""></li>
    <li>
        <input type="checkbox" data-role="checkbox" data-caption="Subtitles" title="">
        <ul>
            <li><input type="checkbox" data-role="checkbox" data-caption="English" title=""></li>
            <li><input checked type="checkbox" data-role="checkbox" data-caption="Ukrainian" title=""></li>
            <li><input type="checkbox" data-role="checkbox" data-caption="Dutch" title=""></li>
        </ul>
    </li>
</ul>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script href="<?php echo e(asset('AdminLTE/plugins/metro/js/metro.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.order', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>