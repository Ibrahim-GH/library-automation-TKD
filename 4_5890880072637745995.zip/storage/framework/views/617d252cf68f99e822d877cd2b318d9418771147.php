<?php $__env->startSection('title', __('Edit Supplier Payment')); ?>

<?php $__env->startSection('head'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-credit-card-alt"></i> <?php echo e(__('Supplier Payments')); ?>

                <small><?php echo e(__('Edit')); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.supplierPayments.index')); ?>"><?php echo e(__('Supplier Payments')); ?></a></li>
                <li class="active"><?php echo e(__('Edit')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Horizontal Form -->
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(__('Edit Supplier Payment')); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <?php echo e(Form::model($payment, ['route' => ['dashboard.supplierPayments.update', $payment->id], 'method' => 'put', 'autocomplete' => 'off'])); ?>

                        <?php echo e(Form::hidden('id')); ?>

                        <div class="box-body">
                            <div class="form-group <?php echo e($errors->has('supplier_id')? 'has-error' : ''); ?>">
                                <?php if($errors->has('supplier_id')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('supplier_id', __('Supplier') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::select('supplier_id', $suppliers, null, ['required', $payment->supplier_id? 'readonly':'', 'class' => 'form-control select2 supplier', 'placeholder' => __('Select Supplier') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('supplier_id')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('date')? 'has-error' : ''); ?>">
                                <?php if($errors->has('date')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('date', __('Date') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::date('date', old('date'), ['required', 'class' => 'form-control', 'placeholder' => __('Select Date') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('time')? 'has-error' : ''); ?>">
                                <?php if($errors->has('time')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('time', __('Time') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::time('time', old('time'), ['required', 'class' => 'form-control', 'placeholder' => __('Select Time') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('time')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('amount')? 'has-error' : ''); ?>">
                                <?php if($errors->has('amount')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('amount', __('Amount') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::number('amount', old('amount'), ['required', 'autofocus', 'class' => 'form-control', 'placeholder' => __('Enter Amount') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('amount')); ?></span>
                            </div>
                            <div class="form-group <?php echo e($errors->has('notes')? 'has-error' : ''); ?>">
                                <?php if($errors->has('notes')): ?>
                                    <i class="fa fa-times-circle-o"></i>
                                <?php endif; ?>
                                <?php echo e(Form::label('notes', __('Notes') . ':', ['class' => 'control-label'])); ?>

                                <?php echo e(Form::textarea('notes', old('notes'), ['class' => 'form-control', 'placeholder' => __('Enter Notes') . '...'])); ?>

                                <span class="help-block"><?php echo e($errors->first('notes')); ?></span>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <?php echo e(link_to_route('dashboard.supplierPayments.index', __('Back'), null, [ 'class' => 'btn btn-default', 'tabindex' => '-1' ])); ?>

                            <?php echo e(Form::submit(__('Update'), ['class' => 'btn btn-primary pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                        <?php echo e(Form::close()); ?>

                    </div>
                    <!-- /.box -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('AdminLTE/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        $(function () {
            $('.select2.supplier').select2();
            $('.select2.supplier').select2('focus');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>