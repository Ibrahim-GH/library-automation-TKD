<?php if(isset($nodes)): ?>
<h2>Nodes</h2>
<ul>
    <?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('trees.show', [ 'id'=> $node->id , 'path_name' => $path_name . ' ' . $node->name])); ?>">
                <?php echo e($path_name . ' ' . $node->name); ?>

            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<?php if(isset($item)): ?>
<h2>Items</h2>
<ul>
    <li>
        <a href="<?php echo e(route('items.show', [ 'id'=> $item->id ])); ?>">
            <?php echo e($item->name); ?>

        </a>
    </li>
</ul>
<?php endif; ?>
