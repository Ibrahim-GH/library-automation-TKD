<?php $__env->startSection('title', 'View Customer Payment'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-money"></i> <?php echo e(__('Customer Payment')); ?>

                <small>#<?php echo e(str_pad($payment->id, 6, "0", STR_PAD_LEFT )); ?></small>
            </h1>
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('Dashboard')); ?></a>
                </li>
                <li><a href="<?php echo e(route('dashboard.customerPayments.index')); ?>"><?php echo e(__('Customer Payments')); ?></a></li>
                <li class="active"><?php echo e(__('View')); ?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="invoice">
            <!-- title row -->
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="page-header">
                        <i class="fa fa-pencil"></i> <?php echo e(config('app.name')); ?>, Com.
                        <small class="pull-right">Date: <?php echo e(date('d/m/Y')); ?></small>
                    </h2>
                </div>
                <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <?php echo e(__('From')); ?>

                    <address>
                        <strong><?php echo e($payment->customer->company); ?></strong><br>
                        <?php echo e($payment->customer->address); ?><br>
                        Phone: <?php echo e($payment->customer->phone); ?><br>
                        Mobile: <?php echo e($payment->customer->mobile); ?><br>
                    </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                    <?php echo e(__('To')); ?>

                    <address>
                        <strong><?php echo e(config('app.name')); ?>, Com.</strong><br>
                        <?php echo e(config('app.address')); ?><br>
                        <?php echo e(__('Phone')); ?>: <?php echo e(config('app.phone')); ?><br>
                        <?php echo e(__('Email')); ?>: <?php echo e(config('app.email')); ?>

                    </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                    <b><?php echo e(__('Payment')); ?> #<?php echo e(str_pad($payment->id, 6, "0", STR_PAD_LEFT )); ?></b><br>
                    <br>
                    <b><?php echo e(__('Amount')); ?>:</b> <?php echo e($payment->amount); ?><br>
                    <b><?php echo e(__('Payment Date')); ?>:</b> <?php echo e(date('d/m/Y', strtotime($payment->date))); ?><br>
                    <b><?php echo e(__('Current Balance')); ?>:</b> <?php echo e($payment->customer->balance); ?>

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- this row will not appear when printing -->
            <div class="row no-print">
                <div class="col-xs-12">
                    <a href="<?php echo e(route('dashboard.customerPayments.print', $payment->id)); ?>" target="_blank" class="btn btn-default"><i
                            class="fa fa-print"></i> <?php echo e(__('Print')); ?></a>
                </div>
            </div>
        </section>
        <!-- /.content -->
        <div class="clearfix"></div>
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>