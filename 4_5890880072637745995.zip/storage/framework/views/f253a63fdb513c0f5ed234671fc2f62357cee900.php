<?php $__env->startSection('title', 'View Bill'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="invoice">
        <!-- title row -->
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    <i class="fa fa-pencil"></i> <?php echo e(config('app.name')); ?>, Com.
                    <small class="pull-right">Date: <?php echo e(date('d/m/Y')); ?></small>
                </h2>
            </div>
            <!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
                From
                <address>
                    <strong><?php echo e(config('app.name')); ?>, Com.</strong><br>
                    <?php echo e(config('app.address')); ?><br>
                    Phone: <?php echo e(config('app.phone')); ?><br>
                    Email: <?php echo e(config('app.email')); ?>

                </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                To
                <address>
                    <strong><?php echo e($payment->supplier->company); ?></strong><br>
                    <?php echo e($payment->supplier->address); ?><br>
                    Phone: <?php echo e($payment->supplier->phone); ?><br>
                    Mobile: <?php echo e($payment->supplier->mobile); ?><br>
                </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                <b><?php echo e(__('Payment')); ?> #<?php echo e(str_pad($payment->id, 6, "0", STR_PAD_LEFT )); ?></b><br>
                <br>
                <b><?php echo e(__('Amount')); ?>:</b> <?php echo e($payment->amount); ?><br>
                <b><?php echo e(__('Payment Date')); ?>:</b> <?php echo e(date('d/m/Y', strtotime($payment->date))); ?><br>
                <b><?php echo e(__('Current Balance')); ?>:</b> <?php echo e($payment->supplier->balance); ?>

            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>